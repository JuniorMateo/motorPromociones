--SH IncumplimientoPago
select * from promt_bono_program p where   p.bono_id=100036    --123100  100037 100036f
select * from promt_bono_program p where p.contract_id=104   and  p.bono_id=7294  for update --BONO_ID=100036 100037
select * from promt_bono_definicion d where d.campania='CLARO MAX FAMILIA' and d.bono_id=8796 
select * from promt_contract_data t where  t.contract_id=92  for update  -- 994883764
select * from promt_contract_data d where   d.contract_id_ext = 'CONTR0000001118' for update
select * from  promt_rateplan_hist t where t.contract_id=92 for update
select * from customer_all;
  select * from promt_customer_all --for update; 22470419
  where customer_id_ext = 'CU_00100001' for update   --CU_00100001
  
declare 
conta integer:=100036;
begin 
  for f in  0..2 loop
    update promt_bono_program p
    set  p.est_bono='A',p.est_proc='CA',p.fec_estado='', p.observacion=''
    where p.contract_id=92 and p.bono_id=conta;
    conta:=conta+1;
  end loop;
  
  EXCEPTION
  WHEN OTHERS
    THEN
      DBMS_OUTPUT.put_line(SQLERRM);
end;
  
  Select cd.dn_num,
                bp.bono_id,
                bp.contract_id,
                pc.customer_id_ext
                 From           promt_bono_program bp 
                 inner join     promt_contract_data cd on bp.contract_id = cd.contract_id
                 inner join     promt_bono_definicion bf on bf.bono_id=bp.bono_id
                 inner join     promt_rateplan_hist rp1 on rp1.contract_id=bp.contract_id
                 inner join     promt_campania_desactiva ds on ds.campania=bf.campania 
                 inner join     promt_customer_all pc on pc.customer_id_ext=cd.customer_id_ext
                 And trunc(rp1.created_date) >= (trunc(sysdate) - 0)
                 And trunc(rp1.created_date) <= trunc(sysdate)
                 And bp.est_bono = 'A'
                  And bp.est_proc = 'CA'
                 And rp1.seqno=(select max(t.seqno) from promt_rateplan_hist t where t.contract_id=rp1.contract_id)
                 And ds.iddesactivacion=1
                 UNION
                 Select    cd.dn_num,
                     bp.bono_id,
                     bp.contract_id,
                     pc.customer_id_ext
                 From           promt_bono_program bp 
                 inner join     promt_contract_data cd on bp.contract_id = cd.contract_id
                 inner join     promt_bono_definicion bf on bf.bono_id=bp.bono_id
							   inner join     promt_rateplan_hist rp1 on rp1.contract_id=bp.contract_id
							   inner join     promt_customer_all pc on pc.customer_id_ext=cd.customer_id_ext
							   inner join     promt_campania_desactiva ds
								on ds.idoperacion=(select t.opertype_id  from promt_operation_type t where t.opertype_desc=bp.tipo_opera)
								 And trunc(rp1.created_date) >= (trunc(sysdate) - 0)
                 And trunc(rp1.created_date) <= trunc(sysdate)
                 And bp.est_bono = 'A'
                 And bp.est_proc = 'CA'
								And rp1.seqno=(select max(t.seqno) from promt_rateplan_hist t where t.contract_id=rp1.contract_id)
								And ds.iddesactivacion=1
								And bf.campania is null;